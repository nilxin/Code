#!/usr/bin/python
# -*- coding: UTF-8 -*-
''' CREATE TEST OBJECTS '''
#DataFrame、Series、index、periods
import pandas as pd
df=pd.DataFrame(np.random.rand(20,5))